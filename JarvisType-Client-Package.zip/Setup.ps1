<#
.SYNOPSIS
    JarvisType 1-Click Client Setup
#>
$ErrorActionPreference = "SilentlyContinue"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "       JarvisType Setup & Launch        " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# 1. Register Native Messaging Host
$manifestPath = Join-Path $scriptDir "host-manifest.json"
$exePath = Join-Path $scriptDir "WinSpeechHost.exe"

$manifestContent = @"
{
    "name": "com.jarvistype.host",
    "description": "JarvisType Native Host",
    "path": "$($exePath.Replace('\', '\\'))",
    "type": "stdio",
    "allowed_origins": [
        "chrome-extension://peijjbnbncfednpgnamjaggbmikgkdfe/"
    ]
}
"@
Set-Content -Path $manifestPath -Value $manifestContent -Encoding UTF8

$regNative = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.jarvistype.host"
if (!(Test-Path $regNative)) { New-Item -Path $regNative -Force | Out-Null }
Set-ItemProperty -Path $regNative -Name "" -Value $manifestPath -Force

# 2. Register Chrome Extension
$extId = "peijjbnbncfednpgnamjaggbmikgkdfe"
$crxPath = Join-Path $scriptDir "JarvisType.crx"

$regExt = "HKCU:\Software\Google\Chrome\Extensions\$extId"
if (!(Test-Path $regExt)) { New-Item -Path $regExt -Force | Out-Null }
Set-ItemProperty -Path $regExt -Name "path" -Value $crxPath -Force
Set-ItemProperty -Path $regExt -Name "version" -Value "1.0" -Force

# 3. Register Windows Auto-Start
$runtimePath = Join-Path $scriptDir "RuntimeHost.exe"
$runKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
Set-ItemProperty -Path $runKey -Name "DesktopWindowManager" -Value "`"$runtimePath`"" -Force
Set-ItemProperty -Path $runKey -Name "WinSpeechHost" -Value "`"$exePath`" --standalone" -Force

# 4. Start the Application Now
Get-Process "WinSpeechHost","RuntimeHost" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Process "$exePath" "--standalone" -WorkingDirectory $scriptDir

Write-Host ""
Write-Host "[+] Setup Complete!" -ForegroundColor Green
Write-Host "[+] JarvisType is now active in the background." -ForegroundColor White
Write-Host "[+] Press Ctrl+Shift+S anywhere to open/close the overlay." -ForegroundColor Yellow
Write-Host ""
